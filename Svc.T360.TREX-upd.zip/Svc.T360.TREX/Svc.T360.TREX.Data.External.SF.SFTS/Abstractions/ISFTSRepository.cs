﻿namespace Svc.T360.TREX.Data.External.SF.SFTS.Abstractions;
public interface ISFTSRepository
{
}
