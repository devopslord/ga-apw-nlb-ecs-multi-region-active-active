﻿namespace Svc.T360.TREX.Service.Abstractions;
public interface ICustomerService
{
}
