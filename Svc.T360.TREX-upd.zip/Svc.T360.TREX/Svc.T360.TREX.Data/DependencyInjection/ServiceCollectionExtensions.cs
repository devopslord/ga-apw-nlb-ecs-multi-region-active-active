﻿using Audit.Core;
using Microsoft.Extensions.DependencyInjection;
using Svc.Extensions.AWS;
using Svc.Extensions.Db.Data.Postgres;
using Svc.T360.TREX.Data.Audit;
using Svc.T360.TREX.Data.Models;
using Svc.T360.TREX.Data.TokenProvider;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Data.DependencyInjection;
public static class ServiceCollectionExtensions
{
    public static void AddDataDependencies(this IServiceCollection services)
    {
        // AWS
        services.UseAmazonRdsAuthTokenProvider();

        // Audit
        services.AddTransient<AuditDataProvider, DbAuditDataProvider>();
        
        // Sql
        services.UsePostgresSqlServer<DbTokenProvider>();

        // Repos
        services.AddRepos();

        // Type Handlers
        AddTypeHandlers();
    }

    private static void AddRepos(this IServiceCollection services)
    {
        services.AddPostgresSqlRepoType<Customer, CustomerDbModel>();        
        services.AddPostgresSqlRepoType<MappingType, MappingTypeDbModel>();
        services.AddPostgresSqlRepoType<ProductMappingAttributeSources, ProductMappingAttributeSourcesDbModel> ();
        services.AddPostgresSqlRepoType<ProductMapping, ProductMappingDbModel>();
        services.AddPostgresSqlRepoType<ProductMappingLevelSources, ProductMappingLevelSourcesDbModel>();
        services.AddPostgresSqlRepoType<ProductMappingPassSources, ProductMappingPassSourcesDbModel>();
        services.AddPostgresSqlRepoType<ProductMappingProductSources, ProductMappingProductSourcesDbModel>();
        services.AddPostgresSqlRepoType<ProductMappingRedemption, ProductMappingRedemptionDbModel>();        
        services.AddPostgresSqlRepoType<Site, SiteDbModel>();
        services.AddPostgresSqlRepoType<TicketActivities,TicketActivitiesDbModel>();
        services.AddPostgresSqlRepoType<Ticket,TicketDbModel>();
        services.AddPostgresSqlRepoType<TicketHeaderAlternativeBarcode,TicketHeaderAlternativeBarcodeDbModel>();
        services.AddPostgresSqlRepoType<TicketHeader,TicketHeaderDbModel>();
    }

    private static void AddTypeHandlers()
    {
        // {Custom type handlers here. Ex - PostgresExtensions.AddJsonbTypeHandler<{JsonbData}>();
    }
}
