﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models
{
    [Table("customers")]
    internal class CustomerDbModel : IDbModel
    {
        [Key]
        public long CustomerId { get; set; }
        [GuidKey]
        public Guid CustomerUid { get; set; }
        [CreatedDateTimeProperty]
        public DateTime CreateDateTime { get; set; }
        public string CreatedBy { get; set; }
        [UpdatedDateTimeProperty]
        public DateTime? UpdatedDateTime { get; set; }
        public string? UpdatedBy { get; set; }
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }
        public string? PictureFile { get; set; }
        public string? Phone1 { get; set; }
        public string? Phone1_Extension { get; set; }
        public string? Phone2 { get; set; }
        public string? Phone2Extension { get; set; }
        public string? Fax { get; set; }
        public string? FaxExtension { get; set; }
        public string? Email { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? Country { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Zip { get; set; }
    }
}
