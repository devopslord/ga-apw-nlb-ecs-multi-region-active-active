﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models
{
    [Table("tickets")]
    internal class TicketDbModel : IDbModel
    {
        [Key]
        public long TicketId { get; set; }
        [GuidKey]
        public Guid TicketUid { get; set; }
        [StringKey]
        public string TicketCode { get; set; } 
        [CreatedDateTimeProperty]
        public DateTime CreateDateTime { get; set; }
        public string CreatedBy { get; set; } 
        public long TicketHeaderId { get; set; }
        [StringKey]
        public string SeasonCode { get; set; }
        [StringKey]
        public string VenueCode { get; set; } 
        public long HomeSiteId { get; set; } 
        public string? Product { get; set; }
        public string? Attribute { get; set; }
        public string? PassType { get; set; }
        [StringKey]
        public string TicketStatusCode { get; set; } 
        public DateTime? StartDate { get; set; }
        public DateTime? End_Date { get; set; }
        public string? ProductType { get; set; }
        public string? ProductLevel { get; set; }      
    }
}
