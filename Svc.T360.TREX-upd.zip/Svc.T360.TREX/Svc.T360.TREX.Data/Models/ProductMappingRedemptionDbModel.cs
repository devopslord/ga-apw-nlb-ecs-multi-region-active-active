﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models;

[Table("product_mappings_redemptions")]
internal class ProductMappingRedemptionDbModel : IDbModel
{
    [Key]
    public long ProductMappingRedemptionId { get; set; }
    public long ProductMappingId { get; set; }
    public int? SharedSiteId { get; set; }
    public int? HomeSiteId { get; set; }
    public string Product { get; set; }
}
