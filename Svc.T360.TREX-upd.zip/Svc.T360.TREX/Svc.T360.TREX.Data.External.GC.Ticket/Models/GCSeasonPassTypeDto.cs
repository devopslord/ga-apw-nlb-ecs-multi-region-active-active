﻿namespace Svc.T360.TREX.Data.External.GC.Ticket.Models;
public class GCSeasonPassTypeDto
{
    public int SeasonPassTypeNo { get; set; }
    public string ExtSeasonPassTypeID { get; set; } = "";
    public string SeasonPassTypeName { get; set; } = "";
    public int? LostPassProductNo { get; set; }
    public int? ForgotPassProductNo { get; set; }
    public int? AnnualValidationPeriod { get; set; }
    public int? LostPassProductNoJrSr { get; set; }
    public int? ResolutionAdultProductNo { get; set; }
    public int? ResolutionJrSrProductNo { get; set; }
    public bool IsSeasonPass { get; set; }
    public int? ForgotPassTicketFormatNo { get; set; }
    public bool IsSharedTicketProgram { get; set; }
    public byte TicketCardTypeNo { get; set; }
    public bool DisableDemographicCapture { get; set; }
    public int? IncentiveRedemptionProductNo { get; set; }
}
