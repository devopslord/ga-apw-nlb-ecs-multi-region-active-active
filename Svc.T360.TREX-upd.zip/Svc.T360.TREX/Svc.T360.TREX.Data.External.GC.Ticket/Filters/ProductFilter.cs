﻿using Svc.Extensions.Core.Value;

namespace Svc.T360.TREX.Data.External.GC.Ticket.Filters;
internal class ProductFilter
{
    public PropertyValue<bool>? IsActive { get; set; }
}
