﻿using Svc.Extensions.Core.Filter;
using Svc.Extensions.Core.Value;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Domain.Filters;
public class MappingTypeFilter : DefaultFilter, IFilter<MappingType>
{
    public PropertyValue<List<Guid>>? MappingTypeUidCollection { get; set; }
    public PropertyValue<Guid>? MappingTypeUid { get; set; }
}
