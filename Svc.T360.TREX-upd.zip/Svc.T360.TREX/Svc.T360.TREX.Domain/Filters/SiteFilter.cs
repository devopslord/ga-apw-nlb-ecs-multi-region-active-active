﻿using Svc.Extensions.Core.Filter;
using Svc.Extensions.Core.Value;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Domain.Filters;
public class SiteFilter : DefaultFilter, IFilter<Site>
{
    public PropertyValue<List<Guid>>? SiteUidCollection { get; set; }
    public PropertyValue<Guid>? SiteUid { get; set; }
}
