﻿using Microsoft.Extensions.DependencyInjection;
using Svc.Extensions.Odm.DependencyInjection;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.DataProvider;
using Svc.T360.TREX.Service.Dto.Mappers;
using Svc.T360.TREX.Service.Dto.Models;
using Svc.T360.TREX.Service.Dto.PropertySetters;

namespace Svc.T360.TREX.Service.Dto.DependencyInjection;
public static class ServiceCollectionExtensions
{
    public static void AddDtoServiceDependencies(this IServiceCollection services)
    {
        // services
        services.AddDtoServices();

        // property setters
        services.AddPropertySetters();

        // odm types
        services.AddOdmTypes();
    }

    private static void AddDtoServices(this IServiceCollection services)
    {
        services.AddDtoService<Customer, CustomerDto, CustomerMapper, BaseDtoServiceDataProvider<Customer>>();        
        services.AddDtoService<Site, SiteDto, SiteMapper, BaseDtoServiceDataProvider<Site>>();        
        services.AddDtoService<MappingType, MappingTypeDto, MappingTypeMapper, BaseDtoServiceDataProvider<MappingType>>();
        services.AddDtoService<ProductMapping, ProductMappingDto, ProductMappingMapper, BaseDtoServiceDataProvider<ProductMapping>>();
    }

    private static void AddPropertySetters(this IServiceCollection services)
    {        
        services.AddPropertySetter<SiteDto, SiteDescriptionSetter>();
        services.AddPropertySetter<CustomerDto, CustomerDescriptionSetter>();
        services.AddPropertySetter<MappingTypeDto, MappingTypeDescriptionSetter>();
        services.AddPropertySetter<ProductMappingDto, ProductMappingDescriptionSetter>();
    }

    private static void AddOdmTypes(this IServiceCollection services)
    {        
        services.AddOdmType<SiteDto>();
        services.AddOdmType<CustomerDto>();
        services.AddOdmType<MappingTypeDto>();
        services.AddOdmType<ProductMappingDto>();
    }
}
