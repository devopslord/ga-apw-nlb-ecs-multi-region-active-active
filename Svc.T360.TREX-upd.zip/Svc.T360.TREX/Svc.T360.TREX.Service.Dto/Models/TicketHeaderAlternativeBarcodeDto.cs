﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models
{
    public class TicketHeaderAlternativeBarcodeDto : IDtoModel<TicketHeaderAlternativeBarcode>
    {
        public int TicketHeaderAlternativeBarcodeId { get; set; }
        public Guid TicketHeaderAlternativeBarcodeUid { get; set; }
        public long TicketHeaderId { get; set; }
        public string? Barcode { get; set; }
        public TicketHeader? TicketHeader { get; set; }
    }
}
