﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models;
public class MappingTypeDto : IDtoModel<MappingType>
{
    public int MappingTypeId { get; set; }
    public Guid MappingTypeUid { get; set; }
    public string? MappingTypeCode { get; set; }
    public string? MappingTypeName { get; set; }
    #region Property Setter Properties
    [OdmRequiredProperty(nameof(MappingTypeCode))]
    [OdmRequiredProperty(nameof(MappingTypeName))]
    public string? Description { get; set; }
    #endregion
}
