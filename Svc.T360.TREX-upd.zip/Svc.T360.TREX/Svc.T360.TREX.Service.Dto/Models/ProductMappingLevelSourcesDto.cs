﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models;
public class ProductMappingLevelSourcesDto : IDtoModel<ProductMappingLevelSources>
{
    public long ProductMappingLevelSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int? SiteSystemId { get; set; }
    public string ProductType { get; set; }
    public string ProductLevel { get; set; }
}
