﻿using HotChocolate;
using HotChocolate.Resolvers;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Odm.HotChocolate;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Filters;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.GraphQL.Queries;

[ExtendObjectType(nameof(Query))]
public class TicketActivitiesQuery
{
    public async Task<GraphQLResponse<IEnumerable<TicketActivitiesDto>>> GetTicketActivitiessAsync(IResolverContext context,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<TicketActivities, TicketActivitiesDto> svc)
        => await operation.ExecuteAsync(nameof(GetTicketActivitiessAsync),
            async () => await svc.GetAllAsync(context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)) ??
                        Enumerable.Empty<TicketActivitiesDto>());

    public async Task<GraphQLResponse<TicketActivitiesDto?>> GetTicketActivitiesAsync(IResolverContext context, long id,
    [Service] IQueryOperation operation, [Service] IBaseDtoService<TicketActivities, TicketActivitiesDto> svc)
    => await operation.ExecuteAsync(nameof(GetTicketActivitiesAsync),
        async () => await svc.GetAsync(id, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));
}
