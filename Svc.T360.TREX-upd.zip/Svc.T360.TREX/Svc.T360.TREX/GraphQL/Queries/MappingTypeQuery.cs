﻿using HotChocolate;
using HotChocolate.Resolvers;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Odm.HotChocolate;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Filters;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.GraphQL.Queries;

[ExtendObjectType(nameof(Query))]
public class MappingTypeQuery
{
    public async Task<GraphQLResponse<IEnumerable<MappingTypeDto>>> GetMappingTypesAsync(IResolverContext context,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<MappingType, MappingTypeDto> svc)
        => await operation.ExecuteAsync(nameof(GetMappingTypesAsync),
            async () => await svc.GetAllAsync(context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)) ??
                        Enumerable.Empty<MappingTypeDto>()); 

    public async Task<GraphQLResponse<MappingTypeDto?>> GetMappingTypeAsync(IResolverContext context, long id,
    [Service] IQueryOperation operation, [Service] IBaseDtoService<MappingType, MappingTypeDto> svc)
    => await operation.ExecuteAsync(nameof(GetMappingTypeAsync),
        async () => await svc.GetAsync(id, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));

    public async Task<GraphQLResponse<IEnumerable<MappingTypeDto>?>> GetMappingTypeByFilterAsync(IResolverContext context, MappingTypeFilter filter,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<MappingType, MappingTypeDto> svc)
        => await operation.ExecuteAsync(nameof(GetMappingTypeByFilterAsync),
            async () => await svc.GetAllByFilterAsync(filter, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));
}
