﻿using Svc.Extensions.Core.Model;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.GraphQL.InputTypes;

public class SiteSaveInput : IInputModel<Site>
{    
    public int SiteId { get; set; }    
    public string? SiteCode { get; set; }
    public string? SiteName { get; set; }
    public int SiteNumber { get; set; }
}
