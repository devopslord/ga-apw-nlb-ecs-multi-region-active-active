﻿using Svc.Extensions.Core.Model;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.GraphQL.InputTypes;

public class ProductMappingPassSourcesSaveInput : IInputModel<ProductMappingPassSources>
{
    public long ProductMappingPassSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int? SiteSystemId { get; set; }
    public string SeasonPassType { get; set; } = "";
}
