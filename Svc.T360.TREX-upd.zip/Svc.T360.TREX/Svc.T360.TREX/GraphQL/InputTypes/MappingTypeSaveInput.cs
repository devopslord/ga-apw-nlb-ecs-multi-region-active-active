﻿using Svc.Extensions.Core.Model;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.GraphQL.InputTypes;

public class MappingTypeSaveInput : IInputModel<MappingType>
{
    public int MappingTypeId { get; set; }
    public string? MappingTypeCode { get; set; }
    public string? MappingTypeName { get; set; }
}
