﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class SiteMutation
{
    public async Task<GraphQLResponse<Site?>> SiteSaveAsync(SiteSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<Site> svc)
        => await operation.ExecuteAsync(nameof(SiteSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<SiteSaveInput, Site>()));

    public async Task<GraphQLResponse<IEnumerable<Site>>> SitesSaveAsync(IEnumerable<SiteSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<Site> svc)
        => await operation.ExecuteAsync(nameof(SitesSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<SiteSaveInput, Site>()).ToList()));
}
