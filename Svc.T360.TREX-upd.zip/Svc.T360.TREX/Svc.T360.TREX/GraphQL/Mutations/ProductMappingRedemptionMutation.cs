﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class ProductMappingRedemptionMutation
{
    public async Task<GraphQLResponse<ProductMappingRedemption?>> ProductMappingRedemptionSaveAsync(ProductMappingRedemptionSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<ProductMappingRedemption> svc)
        => await operation.ExecuteAsync(nameof(ProductMappingRedemptionSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<ProductMappingRedemptionSaveInput, ProductMappingRedemption>()));

    public async Task<GraphQLResponse<IEnumerable<ProductMappingRedemption>>> ProductMappingRedemptionsSaveAsync(IEnumerable<ProductMappingRedemptionSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<ProductMappingRedemption> svc)
        => await operation.ExecuteAsync(nameof(ProductMappingRedemptionsSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<ProductMappingRedemptionSaveInput, ProductMappingRedemption>()).ToList()));
}
