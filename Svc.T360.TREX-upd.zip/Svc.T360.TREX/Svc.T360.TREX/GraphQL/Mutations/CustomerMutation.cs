﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class CustomerMutation
{
    public async Task<GraphQLResponse<Customer?>> CustomerSaveAsync(CustomerSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<Customer> svc)
        => await operation.ExecuteAsync(nameof(CustomerSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<CustomerSaveInput, Customer>()));

    public async Task<GraphQLResponse<IEnumerable<Customer>>> CustomersSaveAsync(IEnumerable<CustomerSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<Customer> svc)
        => await operation.ExecuteAsync(nameof(CustomersSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<CustomerSaveInput, Customer>()).ToList()));
}
