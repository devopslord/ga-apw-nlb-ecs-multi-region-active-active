﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class TicketHeaderAlternativeBarcodeMutation
{
    public async Task<GraphQLResponse<TicketHeaderAlternativeBarcode?>> TicketHeaderAlternativeBarcodeSaveAsync(TicketHeaderAlternativeBarcodeSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<TicketHeaderAlternativeBarcode> svc)
        => await operation.ExecuteAsync(nameof(TicketHeaderAlternativeBarcodeSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<TicketHeaderAlternativeBarcodeSaveInput, TicketHeaderAlternativeBarcode>()));

    public async Task<GraphQLResponse<IEnumerable<TicketHeaderAlternativeBarcode>>> TicketHeaderAlternativeBarcodesSaveAsync(IEnumerable<TicketHeaderAlternativeBarcodeSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<TicketHeaderAlternativeBarcode> svc)
        => await operation.ExecuteAsync(nameof(TicketHeaderAlternativeBarcodesSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<TicketHeaderAlternativeBarcodeSaveInput, TicketHeaderAlternativeBarcode>()).ToList()));
}
