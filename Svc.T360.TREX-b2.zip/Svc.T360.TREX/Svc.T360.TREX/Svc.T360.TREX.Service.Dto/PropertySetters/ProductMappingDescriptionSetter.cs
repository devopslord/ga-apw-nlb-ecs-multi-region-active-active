﻿using Svc.Extensions.Odm.Abstractions;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.PropertySetters;
internal class ProductMappingDescriptionSetter : IPropertySetter<ProductMappingDto>
{
    public string PropertyName => nameof(ProductMappingDto.Description);

    public async Task Set(ProductMappingDto obj, ObjectDefinition? def)
    {
        obj.Description = await Task.FromResult($"[{obj.MappingCode}] {obj.MappingName}");
    }

    public async Task Set(List<ProductMappingDto> collection, ObjectDefinition? def)
    {
        foreach (var obj in collection)
        {
            obj.Description = await Task.FromResult($"[{obj.MappingCode}] {obj.MappingName}");
        }
    }
}
