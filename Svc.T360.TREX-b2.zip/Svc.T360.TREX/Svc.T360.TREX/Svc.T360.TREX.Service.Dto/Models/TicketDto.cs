﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models
{
    public class TicketDto : IDtoModel<Ticket>
    {
        public long TicketId { get; set; }
        public Guid TicketUid { get; set; }
        public string TicketCode { get; set; } 
        public DateTime CreateDateTime { get; set; }
        public string CreatedBy { get; set; } 
        public long TicketHeaderId { get; set; }
        public string SeasonCode { get; set; }
        public string VenueCode { get; set; }
        public int HomeSiteId { get; set; }
        public string? Product { get; set; }
        public string? Attribute { get; set; }
        public string? PassType { get; set; }
        public string TicketStatusCode { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string? ProductType { get; set; }
        public string? ProductLevel { get; set; }
        #region Property Setter Properties
        [OdmRequiredProperty(nameof(TicketCode))]
        public string? Description { get; set; }
        #endregion
    }
}
