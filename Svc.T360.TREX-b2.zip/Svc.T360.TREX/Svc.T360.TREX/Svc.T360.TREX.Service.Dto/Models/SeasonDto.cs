﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models;
public class SeasonDto : IDtoModel<Season>
{
    public int SeasonId { get; set; }
    public Guid SeasonUid { get; set; }
    public DateTime CreateDateTime { get; set; }
    public string CreatedBy { get; set; } = "";
    public DateTime? UpdateDateTime { get; set; }
    public string? UpdatedBy { get; set; }
    public string SeasonCode { get; set; } = "";
    public string SeasonName { get; set; } = "";
    public int SeasonYear { get; set; }

    #region Property Setter Properties
    [OdmRequiredProperty(nameof(SeasonCode))]
    [OdmRequiredProperty(nameof(SeasonName))]
    public string? Description { get; set; }
    #endregion
}
