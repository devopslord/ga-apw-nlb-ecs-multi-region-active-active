﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models;
public class MappingSystemDto : IDtoModel<MappingSystem>
{
    public int MappingSystemId { get; set; }
    public Guid MappingSystemUid { get; set; }
    public string? MappingSystemCode { get; set; }
    public string? MappingSystemName { get; set; }
    #region Property Setter Properties
    [OdmRequiredProperty(nameof(MappingSystemCode))]
    [OdmRequiredProperty(nameof(MappingSystemName))]
    public string? Description { get; set; }
    #endregion
}
