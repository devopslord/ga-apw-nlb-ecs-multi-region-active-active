﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models;
public class ProductMappingDto : IDtoModel<ProductMapping>
{
    public long ProductMappingId { get; set; }
    public Guid ProductMappingUid { get; set; }
    public DateTime CreateDateTime { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedDate_Time { get; set; }
    public string? UpdatedBy { get; set; }
    public string? MappingCode { get; set; }
    public string? MappingName { get; set; }
    public int? MappingTypeId { get; set; }
    #region Property Setter Properties
    [OdmRequiredProperty(nameof(MappingCode))]
    [OdmRequiredProperty(nameof(MappingName))]
    public string? Description { get; set; }
    #endregion
}
