﻿using Riok.Mapperly.Abstractions;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.Mappers;

[Mapper]
public partial class MappingSystemMapper : IMapper<MappingSystem, MappingSystemDto>
{
    public static partial MappingSystemDto ToDto(MappingSystem source);

    public static partial MappingSystem ToModel(MappingSystemDto source);
}
