﻿using Svc.Extensions.Core.Model;
using System;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models;

public sealed class ProductMapping : IModel
{
    [Key]
    public long ProductMappingId { get; set; }   
    public Guid ProductMappingUid { get; set; }   
    public DateTime CreateDateTime { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedDateTime { get; set; }
    public string? UpdatedBy { get; set; }
    public string? MappingCode { get; set; }
    public string? MappingName { get; set; }
    public int? MappingTypeId { get; set; }
}
