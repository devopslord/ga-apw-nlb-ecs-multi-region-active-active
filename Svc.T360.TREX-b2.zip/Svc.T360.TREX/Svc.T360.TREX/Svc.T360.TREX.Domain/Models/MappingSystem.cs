﻿using Svc.Extensions.Core.Model;
using System;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models;

public sealed class MappingSystem : IModel
{
    [Key]
    public int MappingSystemId { get; set; }
    public Guid MappingSystemUid { get; set; }
    public string? MappingSystemCode { get; set; }
    public string? MappingSystemName { get; set; }
}