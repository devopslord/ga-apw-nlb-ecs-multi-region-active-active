﻿using Svc.Extensions.Core.Model;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models;
public class Season : IModel
{
    [Key]
    public int SeasonId { get; set; }
    public Guid SeasonUid { get; set; }
    public DateTime CreateDateTime { get; set; }
    public string CreatedBy { get; set; } = "";
    public DateTime? UpdateDateTime { get; set; }
    public string? UpdatedBy { get; set; }
    public string SeasonCode { get; set; } = "";
    public string SeasonName { get; set; } = "";
    public int SeasonYear { get; set; }
}
