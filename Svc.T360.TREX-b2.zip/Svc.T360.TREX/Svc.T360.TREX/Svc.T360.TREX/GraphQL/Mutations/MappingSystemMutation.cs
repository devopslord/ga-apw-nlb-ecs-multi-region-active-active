﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class MappingSystemMutation
{
    public async Task<GraphQLResponse<MappingSystem?>> MappingSystemSaveAsync(MappingSystemSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<MappingSystem> svc)
        => await operation.ExecuteAsync(nameof(MappingSystemSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<MappingSystemSaveInput, MappingSystem>()));

    public async Task<GraphQLResponse<IEnumerable<MappingSystem>>> MappingSystemsSaveAsync(IEnumerable<MappingSystemSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<MappingSystem> svc)
        => await operation.ExecuteAsync(nameof(MappingSystemsSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<MappingSystemSaveInput, MappingSystem>()).ToList()));
}
