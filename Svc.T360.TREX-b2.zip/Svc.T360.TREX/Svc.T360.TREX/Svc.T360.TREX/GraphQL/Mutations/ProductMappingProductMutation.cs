﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class ProductMappingProductSourcesMutation
{
    public async Task<GraphQLResponse<ProductMappingProductSources?>> ProductMappingProductSourcesSaveAsync(ProductMappingProductSourcesSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<ProductMappingProductSources> svc)
        => await operation.ExecuteAsync(nameof(ProductMappingProductSourcesSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<ProductMappingProductSourcesSaveInput, ProductMappingProductSources>()));

    public async Task<GraphQLResponse<IEnumerable<ProductMappingProductSources>>> ProductMappingProductSourcessSaveAsync(IEnumerable<ProductMappingProductSourcesSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<ProductMappingProductSources> svc)
        => await operation.ExecuteAsync(nameof(ProductMappingProductSourcessSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<ProductMappingProductSourcesSaveInput, ProductMappingProductSources>()).ToList()));
}
