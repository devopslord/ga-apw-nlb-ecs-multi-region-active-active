﻿using Svc.Extensions.Core.Model;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.GraphQL.InputTypes;

public class MappingSystemSaveInput : IInputModel<MappingSystem>
{
    public int MappingSystemId { get; set; }
    public string? MappingSystemCode { get; set; }
    public string? MappingSystemName { get; set; }
}
