﻿using Svc.Extensions.Core.Model;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.GraphQL.InputTypes;

public class ProductMappingLevelSourcesSaveInput : IInputModel<ProductMappingLevelSources>
{
    public long ProductMappingLevelSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int? SiteSystemId { get; set; }
    public string ProductType { get; set; } = "";
    public string ProductLevel { get; set; } = "";
}
