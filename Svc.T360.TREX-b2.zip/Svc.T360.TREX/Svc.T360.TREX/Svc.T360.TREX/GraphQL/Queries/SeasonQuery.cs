﻿using HotChocolate;
using HotChocolate.Resolvers;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Odm.HotChocolate;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Filters;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.GraphQL.Queries;

[ExtendObjectType(nameof(Query))]
public class SeasonQuery
{
    public async Task<GraphQLResponse<IEnumerable<SeasonDto>>> GetSeasonsAsync(IResolverContext context,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<Season, SeasonDto> svc)
        => await operation.ExecuteAsync(nameof(GetSeasonsAsync),
            async () => await svc.GetAllAsync(context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)) ??
                        Enumerable.Empty<SeasonDto>());

    public async Task<GraphQLResponse<IEnumerable<SeasonDto>>> GetSeasonsByIdsAsync(IResolverContext context, List<long> idCollection,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<Season, SeasonDto> svc)
        => await operation.ExecuteAsync(nameof(GetSeasonsByIdsAsync),
            async () => await svc.GetAllAsync(idCollection, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)) ??
                        Enumerable.Empty<SeasonDto>());

    public async Task<GraphQLResponse<SeasonDto?>> GetSeasonAsync(IResolverContext context, long id,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<Season, SeasonDto> svc)
        => await operation.ExecuteAsync(nameof(GetSeasonAsync),
            async () => await svc.GetAsync(id, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));

    public async Task<GraphQLResponse<SeasonDto?>> GetSeasonByStringIdAsync(IResolverContext context, string id,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<Season, SeasonDto> svc)
        => await operation.ExecuteAsync(nameof(GetSeasonByStringIdAsync),
            async () => await svc.GetAsync(id, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));

    public async Task<GraphQLResponse<IEnumerable<SeasonDto>?>> GetSeasonByFilterAsync(IResolverContext context, SeasonFilter filter,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<Season, SeasonDto> svc)
        => await operation.ExecuteAsync(nameof(GetSeasonByFilterAsync),
            async () => await svc.GetAllByFilterAsync(filter, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));
}
