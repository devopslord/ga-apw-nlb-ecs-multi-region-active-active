﻿using HotChocolate;
using HotChocolate.Resolvers;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Odm.HotChocolate;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Filters;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.GraphQL.Queries;

[ExtendObjectType(nameof(Query))]
public class ProductMappingAttributeSourcesQuery
{
    public async Task<GraphQLResponse<IEnumerable<ProductMappingAttributeSourcesDto>>> GetProductMappingAttributeSourcessAsync(IResolverContext context,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<ProductMappingAttributeSources, ProductMappingAttributeSourcesDto> svc)
        => await operation.ExecuteAsync(nameof(GetProductMappingAttributeSourcessAsync),
            async () => await svc.GetAllAsync(context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)) ??
                        Enumerable.Empty<ProductMappingAttributeSourcesDto>());

    public async Task<GraphQLResponse<ProductMappingAttributeSourcesDto?>> GetProductMappingAttributeSourcesAsync(IResolverContext context, long id,
    [Service] IQueryOperation operation, [Service] IBaseDtoService<ProductMappingAttributeSources, ProductMappingAttributeSourcesDto> svc)
    => await operation.ExecuteAsync(nameof(GetProductMappingAttributeSourcesAsync),
        async () => await svc.GetAsync(id, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));
}
