﻿using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Svc.T360.TREX.Data.Models;
[Table("seasons")]
internal class SeasonDbModel : IDbModel
{
    [Key]
    public int SeasonId { get; set; }
    [GuidKey]
    public Guid SeasonUid { get; set; }
    [CreatedDateTimeProperty]
    public DateTime CreateDateTime { get; set; }
    public string CreatedBy { get; set; } = "";
    [UpdatedDateTimeProperty]
    public DateTime? UpdateDateTime { get; set; }
    public string? UpdatedBy { get; set; }
    [StringKey]
    public string SeasonCode { get; set; } = "";
    public string SeasonName { get; set; } = "";
    public int SeasonYear { get; set; }
}
