﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models;

[Table("product_mappings")]
internal class ProductMappingDbModel : IDbModel
{
    [Key]
    public long ProductMappingId { get; set; }
    [GuidKey]
    public Guid ProductMappingUid { get; set; }
    [CreatedDateTimeProperty]
    public DateTime CreateDateTime { get; set; }
    public string? CreatedBy { get; set; }
    [UpdatedDateTimeProperty]
    public DateTime? UpdatedDateTime { get; set; }    
    public string? UpdatedBy { get; set; }
    [StringKey] 
    public string? MappingCode { get; set; }
    public string? MappingName { get; set; }   
    public int? MappingTypeId { get; set; }    
}
