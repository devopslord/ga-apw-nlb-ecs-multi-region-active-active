﻿using Svc.Extensions.Db.Data.Abstractions.Core;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Data.Abstractions;
public interface ISeasonRepository : IDbRepository<Season>
{
}
