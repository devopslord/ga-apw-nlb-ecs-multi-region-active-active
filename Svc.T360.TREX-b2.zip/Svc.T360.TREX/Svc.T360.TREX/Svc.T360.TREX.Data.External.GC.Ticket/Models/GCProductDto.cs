﻿namespace Svc.T360.TREX.Data.External.GC.Ticket.Models;
public class GCProductDto
{
    public int ProductNo { get; set; }
    public string ExtProductID { get; set; } = "";
    public string ProductName { get; set; } = "";

    // add more properties if needed
}
