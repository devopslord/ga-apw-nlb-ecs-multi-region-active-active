﻿using Svc.T360.TREX.Data.External.GC.Ticket.Models;

namespace Svc.T360.TREX.Data.External.GC.Ticket.Abstractions;
public interface IGCTicketRepository
{
    Task<IEnumerable<GCProductDto>?> GetAllActiveProductsAsync(string siteId);
    Task<IEnumerable<GCProductAttributeDto>?> GetAllProductAttributesAsync(string siteId);
    Task<IEnumerable<GCSeasonPassTypeDto>?> GetAllSeasonPassTypesAsync(string siteId);
}
