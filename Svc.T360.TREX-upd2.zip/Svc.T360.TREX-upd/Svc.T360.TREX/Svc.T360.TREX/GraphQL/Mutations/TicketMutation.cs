﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class TicketMutation
{
    public async Task<GraphQLResponse<Ticket?>> TicketSaveAsync(TicketSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<Ticket> svc)
        => await operation.ExecuteAsync(nameof(TicketSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<TicketSaveInput, Ticket>()));

    public async Task<GraphQLResponse<IEnumerable<Ticket>>> TicketsSaveAsync(IEnumerable<TicketSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<Ticket> svc)
        => await operation.ExecuteAsync(nameof(TicketsSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<TicketSaveInput, Ticket>()).ToList()));
}
