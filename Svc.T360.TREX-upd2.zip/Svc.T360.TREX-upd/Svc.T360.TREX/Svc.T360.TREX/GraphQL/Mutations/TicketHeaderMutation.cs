﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class TicketHeaderMutation
{
    public async Task<GraphQLResponse<TicketHeader?>> TicketHeaderSaveAsync(TicketHeaderSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<TicketHeader> svc)
        => await operation.ExecuteAsync(nameof(TicketHeaderSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<TicketHeaderSaveInput, TicketHeader>()));

    public async Task<GraphQLResponse<IEnumerable<TicketHeader>>> TicketHeadersSaveAsync(IEnumerable<TicketHeaderSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<TicketHeader> svc)
        => await operation.ExecuteAsync(nameof(TicketHeadersSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<TicketHeaderSaveInput, TicketHeader>()).ToList()));
}
