﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class MappingTypeMutation
{
    public async Task<GraphQLResponse<MappingType?>> MappingTypeSaveAsync(MappingTypeSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<MappingType> svc)
        => await operation.ExecuteAsync(nameof(MappingTypeSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<MappingTypeSaveInput, MappingType>()));

    public async Task<GraphQLResponse<IEnumerable<MappingType>>> MappingTypesSaveAsync(IEnumerable<MappingTypeSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<MappingType> svc)
        => await operation.ExecuteAsync(nameof(MappingTypesSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<MappingTypeSaveInput, MappingType>()).ToList()));
}
