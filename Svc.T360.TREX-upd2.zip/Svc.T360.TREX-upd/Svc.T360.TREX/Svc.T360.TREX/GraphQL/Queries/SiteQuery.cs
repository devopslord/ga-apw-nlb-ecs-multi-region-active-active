﻿using HotChocolate;
using HotChocolate.Resolvers;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Odm.HotChocolate;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Filters;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.GraphQL.Queries;

[ExtendObjectType(nameof(Query))]
public class SiteQuery
{
    public async Task<GraphQLResponse<IEnumerable<SiteDto>>> GetSitesAsync(IResolverContext context,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<Site, SiteDto> svc)
        => await operation.ExecuteAsync(nameof(GetSitesAsync),
            async () => await svc.GetAllAsync(context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)) ??
                        Enumerable.Empty<SiteDto>());

    public async Task<GraphQLResponse<SiteDto?>> GetSiteAsync(IResolverContext context, long id,
    [Service] IQueryOperation operation, [Service] IBaseDtoService<Site, SiteDto> svc)
    => await operation.ExecuteAsync(nameof(GetSiteAsync),
        async () => await svc.GetAsync(id, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));

    public async Task<GraphQLResponse<IEnumerable<SiteDto>?>> GetSiteByFilterAsync(IResolverContext context, SiteFilter filter,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<Site, SiteDto> svc)
        => await operation.ExecuteAsync(nameof(GetSiteByFilterAsync),
            async () => await svc.GetAllByFilterAsync(filter, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));
}
