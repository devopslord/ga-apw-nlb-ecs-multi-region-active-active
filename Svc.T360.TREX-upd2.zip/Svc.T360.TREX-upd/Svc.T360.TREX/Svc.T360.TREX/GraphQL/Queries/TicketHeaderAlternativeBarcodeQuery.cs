﻿using HotChocolate;
using HotChocolate.Resolvers;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Odm.HotChocolate;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Filters;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.GraphQL.Queries;

[ExtendObjectType(nameof(Query))]
public class TicketHeaderAlternativeBarcodeQuery
{
    public async Task<GraphQLResponse<IEnumerable<TicketHeaderAlternativeBarcodeDto>>> GetTicketHeaderAlternativeBarcodesAsync(IResolverContext context,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<TicketHeaderAlternativeBarcode, TicketHeaderAlternativeBarcodeDto> svc)
        => await operation.ExecuteAsync(nameof(GetTicketHeaderAlternativeBarcodesAsync),
            async () => await svc.GetAllAsync(context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)) ??
                        Enumerable.Empty<TicketHeaderAlternativeBarcodeDto>());

    public async Task<GraphQLResponse<TicketHeaderAlternativeBarcodeDto?>> GetTicketHeaderAlternativeBarcodeAsync(IResolverContext context, long id,
    [Service] IQueryOperation operation, [Service] IBaseDtoService<TicketHeaderAlternativeBarcode, TicketHeaderAlternativeBarcodeDto> svc)
    => await operation.ExecuteAsync(nameof(GetTicketHeaderAlternativeBarcodeAsync),
        async () => await svc.GetAsync(id, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));
}
