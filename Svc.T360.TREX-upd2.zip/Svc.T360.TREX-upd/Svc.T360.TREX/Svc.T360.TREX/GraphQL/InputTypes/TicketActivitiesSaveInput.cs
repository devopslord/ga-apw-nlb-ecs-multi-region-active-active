﻿using Svc.Extensions.Core.Model;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.GraphQL.InputTypes;

public class TicketActivitiesSaveInput : IInputModel<TicketActivities>
{
    public long TicketActivityId { get; set; }
    public int TicketId { get; set; }
    public DateTime? ActivityDate { get; set; }
    public DateTime? ActivityTime { get; set; }
    public int ProductMappingId { get; set; }
    public int SharedSiteId { get; set; }
    public string? RedemptionProduct { get; set; }
}
