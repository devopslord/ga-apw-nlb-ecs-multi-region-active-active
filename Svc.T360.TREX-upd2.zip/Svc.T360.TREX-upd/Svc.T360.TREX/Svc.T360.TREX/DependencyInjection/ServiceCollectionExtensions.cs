﻿using Quest.Http.DependencyInjection;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Api.Operation;
using Svc.Extensions.Hosting.Startup;
using Svc.Extensions.Security;
using Svc.T360.TREX.Data.DependencyInjection;
using Svc.T360.TREX.Data.External.GC.Ticket.DependencyInjection;
using Svc.T360.TREX.Data.External.SF.SFTS.DependencyInjection;
using Svc.T360.TREX.GraphQL.Mutations;
using Svc.T360.TREX.GraphQL.Queries;
using Svc.T360.TREX.Service.DependencyInjection;
using Svc.T360.TREX.Service.Dto.DependencyInjection;
using Svc.T360.TREX.Startup;
using System.Net;
using Svc.T360.TREX.GraphQL.Queries.GC;

namespace Svc.T360.TREX.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static void AddGraphQLDependencies(this IServiceCollection services)
    {
        // Operations
        services.UseGraphQLOperations();

        // Exception Mappings
        GraphQLResponseHelper.AddExceptionResponseMap<AuthException>(HttpStatusCode.Unauthorized);

        // GraphQL
        services.UseGraphQL()
            .UseQueryType()
            .UseMutationType()
            .AddPingQuery()
            .AddHealthQuery()
            // queries
            .AddType<SiteQuery>()
            .AddType<CustomerQuery>()
            .AddType<MappingTypeQuery>()
            .AddType<ProductMappingAttributeSourcesQuery>()
            .AddType<ProductMappingLevelSourcesQuery>()
            .AddType<ProductMappingPassSourcesQuery>()
            .AddType<ProductMappingProductSourcesQuery>()
            .AddType<ProductMappingRedemptionQuery>()
            .AddType<ProductMappingQuery>()
            .AddType<TicketHeaderQuery>()
            .AddType<TicketQuery>()
            .AddType<TicketHeaderAlternativeBarcodeQuery>()
            .AddType<TicketActivitiesQuery>()
            
            // mutations            
            .AddType<CustomerMutation>()            
            .AddType<MappingTypeMutation>()
            .AddType<TicketMutation>()
            .AddType<ProductMappingMutation>()
            .AddType<ProductMappingAttributeSourcesMutation>()
            .AddType<ProductMappingLevelSourcesMutation>()
            .AddType<ProductMappingPassSourcesMutation>()
            .AddType<ProductMappingProductSourcesMutation>()
            .AddType<ProductMappingRedemptionMutation>()
            .AddType<TicketHeaderMutation>()
            .AddType<TicketActivitiesMutation>()
            .AddType<TicketHeaderAlternativeBarcodeMutation>()
            .AddType<SiteMutation>()
            // GC
            .AddType<GCDataQuery>();
    }

    public static void AddApplicationDependencies(this IServiceCollection services)
    {
        // Startup
        services.AddStartupService<StartupService>();
        
        // Data
        services.AddDataDependencies();

        // Service
        services.AddServiceDependencies();

        // Dto Service
        services.AddDtoServiceDependencies();

        // External Data
        services.AddExternalDataDependencies();
    }

    private static void AddExternalDataDependencies(this IServiceCollection services)
    {
        // Quest
        services.AddQuest();

        // External Data Dependencies
        services.AddExternalGCTicketDependencies();
        services.AddExternalSFTSDependencies();
    }
}
