﻿using Svc.Extensions.Odm.Abstractions;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.PropertySetters;
internal class SiteDescriptionSetter : IPropertySetter<SiteDto>
{
    public string PropertyName => nameof(SiteDto.Description);

    public async Task Set(SiteDto obj, ObjectDefinition? def)
    {
        obj.Description = await Task.FromResult($"[{obj.SiteCode}] {obj.SiteName}");
    }

    public async Task Set(List<SiteDto> collection, ObjectDefinition? def)
    {
        foreach (var obj in collection)
        {
            obj.Description = await Task.FromResult($"[{obj.SiteCode}] {obj.SiteName}");
        }
    }
}
