﻿using Svc.Extensions.Odm.Abstractions;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.PropertySetters;
internal class CustomerDescriptionSetter : IPropertySetter<CustomerDto>
{
    public string PropertyName => nameof(CustomerDto.Description);

    public async Task Set(CustomerDto obj, ObjectDefinition? def)
    {
        obj.Description = await Task.FromResult($"[{obj.CustomerCode}] {obj.CustomerName}");
    }

    public async Task Set(List<CustomerDto> collection, ObjectDefinition? def)
    {
        foreach (var obj in collection)
        {
            obj.Description = await Task.FromResult($"[{obj.CustomerCode}] {obj.CustomerName}");
        }
    }
}
