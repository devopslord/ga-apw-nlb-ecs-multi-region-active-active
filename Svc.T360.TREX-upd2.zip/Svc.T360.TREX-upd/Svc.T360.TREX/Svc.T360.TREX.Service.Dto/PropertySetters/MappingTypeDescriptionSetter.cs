﻿using Svc.Extensions.Odm.Abstractions;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.PropertySetters;
internal class MappingTypeDescriptionSetter : IPropertySetter<MappingTypeDto>
{
    public string PropertyName => nameof(MappingTypeDto.Description);

    public async Task Set(MappingTypeDto obj, ObjectDefinition? def)
    {
        obj.Description = await Task.FromResult($"[{obj.MappingTypeCode}] {obj.MappingTypeName}");
    }

    public async Task Set(List<MappingTypeDto> collection, ObjectDefinition? def)
    {
        foreach (var obj in collection)
        {
            obj.Description = await Task.FromResult($"[{obj.MappingTypeCode}] {obj.MappingTypeName}");
        }
    }
}
