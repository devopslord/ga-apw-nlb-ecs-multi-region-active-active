﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models;

[Table("mapping_types")]
internal class MappingTypeDbModel : IDbModel
{
    [Key]
    public int MappingTypeId { get; set; }
    [GuidKey]
    public Guid MappingTypeUid { get; set; }
    [StringKey]
    public string? MappingTypeCode { get; set; }
    public string? MappingTypeName { get; set; }
}