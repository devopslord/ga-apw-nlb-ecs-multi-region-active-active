﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models;

[Table("ticket_header_alternative_barcodes")]
internal class TicketHeaderAlternativeBarcodeDbModel : IDbModel
{
    [Key]
    public int TicketHeaderAlternativeBarcodeId { get; set; }
    [GuidKey]
    public Guid TicketHeaderAlternativeBarcodeUid { get; set; }
    public long TicketHeaderId { get; set; }
    public string? Barcode { get; set; }    
}