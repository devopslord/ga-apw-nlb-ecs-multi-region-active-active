﻿using Svc.Extensions.Core.Model;
using System;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models;

public sealed class MappingType : IModel
{
    [Key]
    public int MappingTypeId { get; set; }
    public Guid MappingTypeUid { get; set; }
    public string? MappingTypeCode { get; set; }
    public string? MappingTypeName { get; set; }
}