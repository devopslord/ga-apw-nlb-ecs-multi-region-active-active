﻿using Svc.Extensions.Core.Filter;
using Svc.Extensions.Core.Value;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Domain.Filters;
public class TicketHeaderFilter : DefaultFilter, IFilter<TicketHeader>
{
    public PropertyValue<List<Guid>>? TicketHeaderUidCollection { get; set; }
    public PropertyValue<Guid>? TicketHeaderUid { get; set; }
}
