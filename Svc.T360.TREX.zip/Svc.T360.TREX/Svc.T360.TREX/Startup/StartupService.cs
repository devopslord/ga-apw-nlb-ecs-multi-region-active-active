﻿using Svc.Extensions.Hosting.Startup;

namespace Svc.T360.TREX.Startup;

public class StartupService(ILogger<StartupService> logger, IServiceScopeFactory serviceScopeFactory)
    : IStartupService
{
    public async Task ExecuteAsync()
    {
        try
        {
            logger.LogInformation("[startup_service][start]");

            using (var scope = serviceScopeFactory.CreateScope())
            {
                // {Scoped health check code here}
            }

            logger.LogInformation("[startup_service][complete]");
        }
        catch (Exception e)
        {
            logger.LogError(e, "[startup_service][error] {ErrorMessage}", e.Message);
        }
    }
}
