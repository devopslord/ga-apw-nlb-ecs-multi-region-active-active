﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class ProductMappingPassSourcesMutation
{
    public async Task<GraphQLResponse<ProductMappingPassSources?>> ProductMappingPassSourcesSaveAsync(ProductMappingPassSourcesSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<ProductMappingPassSources> svc)
        => await operation.ExecuteAsync(nameof(ProductMappingPassSourcesSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<ProductMappingPassSourcesSaveInput, ProductMappingPassSources>()));

    public async Task<GraphQLResponse<IEnumerable<ProductMappingPassSources>>> ProductMappingPassSourcessSaveAsync(IEnumerable<ProductMappingPassSourcesSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<ProductMappingPassSources> svc)
        => await operation.ExecuteAsync(nameof(ProductMappingPassSourcessSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<ProductMappingPassSourcesSaveInput, ProductMappingPassSources>()).ToList()));
}
