﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class TicketActivitiesMutation
{
    public async Task<GraphQLResponse<TicketActivities?>> TicketActivitiesSaveAsync(TicketActivitiesSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<TicketActivities> svc)
        => await operation.ExecuteAsync(nameof(TicketActivitiesSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<TicketActivitiesSaveInput, TicketActivities>()));

    public async Task<GraphQLResponse<IEnumerable<TicketActivities>>> TicketActivitiessSaveAsync(IEnumerable<TicketActivitiesSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<TicketActivities> svc)
        => await operation.ExecuteAsync(nameof(TicketActivitiessSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<TicketActivitiesSaveInput, TicketActivities>()).ToList()));
}
