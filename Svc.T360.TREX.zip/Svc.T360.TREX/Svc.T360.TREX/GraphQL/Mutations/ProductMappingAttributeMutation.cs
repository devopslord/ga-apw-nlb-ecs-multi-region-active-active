﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class ProductMappingAttributeSourcesMutation
{
    public async Task<GraphQLResponse<ProductMappingAttributeSources?>> ProductMappingAttributeSourcesSaveAsync(ProductMappingAttributeSourcesSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<ProductMappingAttributeSources> svc)
        => await operation.ExecuteAsync(nameof(ProductMappingAttributeSourcesSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<ProductMappingAttributeSourcesSaveInput, ProductMappingAttributeSources>()));

    public async Task<GraphQLResponse<IEnumerable<ProductMappingAttributeSources>>> ProductMappingAttributeSourcessSaveAsync(IEnumerable<ProductMappingAttributeSourcesSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<ProductMappingAttributeSources> svc)
        => await operation.ExecuteAsync(nameof(ProductMappingAttributeSourcessSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<ProductMappingAttributeSourcesSaveInput, ProductMappingAttributeSources>()).ToList()));
}
