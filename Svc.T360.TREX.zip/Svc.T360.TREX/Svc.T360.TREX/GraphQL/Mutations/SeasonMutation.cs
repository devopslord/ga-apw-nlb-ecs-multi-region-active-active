﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class SeasonMutation
{
    public async Task<GraphQLResponse<Season?>> SeasonSaveAsync(SeasonSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<Season> svc)
        => await operation.ExecuteAsync(nameof(SeasonSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<SeasonSaveInput, Season>()));

    public async Task<GraphQLResponse<IEnumerable<Season>>> SeasonsSaveAsync(IEnumerable<SeasonSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<Season> svc)
        => await operation.ExecuteAsync(nameof(SeasonsSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<SeasonSaveInput, Season>()).ToList()));
}
