﻿using HotChocolate;
using HotChocolate.Resolvers;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Odm.HotChocolate;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Filters;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.GraphQL.Queries;

[ExtendObjectType(nameof(Query))]
public class MappingSystemQuery
{
    public async Task<GraphQLResponse<IEnumerable<MappingSystemDto>>> GetMappingSystemsAsync(IResolverContext context,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<MappingSystem, MappingSystemDto> svc)
        => await operation.ExecuteAsync(nameof(GetMappingSystemsAsync),
            async () => await svc.GetAllAsync(context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)) ??
                        Enumerable.Empty<MappingSystemDto>());

    public async Task<GraphQLResponse<MappingSystemDto?>> GetMappingSystemAsync(IResolverContext context, long id,
    [Service] IQueryOperation operation, [Service] IBaseDtoService<MappingSystem, MappingSystemDto> svc)
    => await operation.ExecuteAsync(nameof(GetMappingSystemAsync),
        async () => await svc.GetAsync(id, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));

    public async Task<GraphQLResponse<IEnumerable<MappingSystemDto>?>> GetMappingSystemByFilterAsync(IResolverContext context, MappingSystemFilter filter,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<MappingSystem, MappingSystemDto> svc)
        => await operation.ExecuteAsync(nameof(GetMappingSystemByFilterAsync),
            async () => await svc.GetAllByFilterAsync(filter, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));
}
