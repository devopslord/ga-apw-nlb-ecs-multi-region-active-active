﻿using HotChocolate;
using HotChocolate.Resolvers;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Odm.HotChocolate;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Filters;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.GraphQL.Queries;

[ExtendObjectType(nameof(Query))]
public class ProductMappingPassSourcesQuery
{
    public async Task<GraphQLResponse<IEnumerable<ProductMappingPassSourcesDto>>> GetProductMappingPassSourcessAsync(IResolverContext context,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<ProductMappingPassSources, ProductMappingPassSourcesDto> svc)
        => await operation.ExecuteAsync(nameof(GetProductMappingPassSourcessAsync),
            async () => await svc.GetAllAsync(context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)) ??
                        Enumerable.Empty<ProductMappingPassSourcesDto>());

    public async Task<GraphQLResponse<ProductMappingPassSourcesDto?>> GetProductMappingPassSourcesAsync(IResolverContext context, long id,
    [Service] IQueryOperation operation, [Service] IBaseDtoService<ProductMappingPassSources, ProductMappingPassSourcesDto> svc)
    => await operation.ExecuteAsync(nameof(GetProductMappingPassSourcesAsync),
        async () => await svc.GetAsync(id, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));
}
