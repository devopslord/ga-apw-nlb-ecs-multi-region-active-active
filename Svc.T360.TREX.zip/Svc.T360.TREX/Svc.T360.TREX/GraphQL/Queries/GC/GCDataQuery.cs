﻿using HotChocolate;
using HotChocolate.Resolvers;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core;
using Svc.T360.TREX.Data.External.GC.Ticket.Abstractions;
using Svc.T360.TREX.Data.External.GC.Ticket.Models;

namespace Svc.T360.TREX.GraphQL.Queries.GC;

[ExtendObjectType(nameof(Query))]
public class GCDataQuery
{
    public async Task<GraphQLResponse<IEnumerable<GCProductDto>>> GetGCProductsAsync(IResolverContext context, string siteId,
        [Service] IQueryOperation operation, [Service] IGCTicketRepository repo)
        => await operation.ExecuteAsync(nameof(GetGCProductsAsync),
            async () => (await repo.GetAllActiveProductsAsync(siteId)).OrEmptyEnumerable());


    public async Task<GraphQLResponse<IEnumerable<GCProductAttributeDto>>> GetGCProductAttributesAsync(IResolverContext context, string siteId,
        [Service] IQueryOperation operation, [Service] IGCTicketRepository repo)
        => await operation.ExecuteAsync(nameof(GetGCProductAttributesAsync),
            async () => (await repo.GetAllProductAttributesAsync(siteId)).OrEmptyEnumerable());

    public async Task<GraphQLResponse<IEnumerable<GCSeasonPassTypeDto>>> GetGCSeasonPassTypesAsync(IResolverContext context, string siteId,
       [Service] IQueryOperation operation, [Service] IGCTicketRepository repo)
       => await operation.ExecuteAsync(nameof(GetGCSeasonPassTypesAsync),
           async () => (await repo.GetAllSeasonPassTypesAsync(siteId)).OrEmptyEnumerable());
}
