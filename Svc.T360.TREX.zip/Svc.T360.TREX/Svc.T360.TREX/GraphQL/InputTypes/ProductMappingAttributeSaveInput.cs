﻿using Svc.Extensions.Core.Model;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.GraphQL.InputTypes;

public class ProductMappingAttributeSourcesSaveInput : IInputModel<ProductMappingAttributeSources>
{
    public long ProductMappingAttributeSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int? SiteSystemId { get; set; }
    public string ProductAttribute { get; set; } = "";
}
