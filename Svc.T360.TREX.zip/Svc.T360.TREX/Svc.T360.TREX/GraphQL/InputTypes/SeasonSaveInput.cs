﻿using Svc.Extensions.Core.Model;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.GraphQL.InputTypes;

public class SeasonSaveInput : IInputModel<Season>
{
    public int SeasonId { get; set; }
    public string CreatedBy { get; set; } = "";
    public string? UpdatedBy { get; set; }
    public string SeasonCode { get; set; } = "";
    public string SeasonName { get; set; } = "";
    public int SeasonYear { get; set; }
}
