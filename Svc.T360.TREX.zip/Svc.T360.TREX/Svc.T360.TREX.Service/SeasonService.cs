﻿using Svc.T360.TREX.Service.Abstractions;

namespace Svc.T360.TREX.Service;
internal class SeasonService : ISeasonService
{
}
