﻿using Microsoft.Extensions.DependencyInjection;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.DataProvider;

namespace Svc.T360.TREX.Service.DependencyInjection;
public static class ServiceCollectionExtensions
{
    public static void AddServiceDependencies(this IServiceCollection services)
    {
        // Services
        services.AddBaseServices();
        services.AddServices();
    }

    private static void AddBaseServices(this IServiceCollection services)
    {
        services.AddBaseServiceType<Season, BaseServiceDataProvider<Season>>();
        services.AddBaseServiceType<Customer, BaseServiceDataProvider<Customer>>();
        services.AddBaseServiceType<MappingSystem, BaseServiceDataProvider<MappingSystem>>();
        services.AddBaseServiceType<MappingType, BaseServiceDataProvider<MappingType>>();
        services.AddBaseServiceType<ProductMapping, BaseServiceDataProvider<ProductMapping>>();
        services.AddBaseServiceType<Site, BaseServiceDataProvider<Site>>();
        services.AddBaseServiceType<Ticket, BaseServiceDataProvider<Ticket>>();
        services.AddBaseServiceType<TicketHeader, BaseServiceDataProvider<TicketHeader>>();
        services.AddBaseServiceType<TicketHeaderAlternativeBarcode, BaseServiceDataProvider<TicketHeaderAlternativeBarcode>>();
    }

    private static void AddServices(this IServiceCollection services)
    {
        //services.AddScoped<IExampleService, ExampleService>();
    }
}
