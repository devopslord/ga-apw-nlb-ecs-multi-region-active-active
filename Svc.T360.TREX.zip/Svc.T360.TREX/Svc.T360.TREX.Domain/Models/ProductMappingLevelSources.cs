﻿using Svc.Extensions.Core.Model;
using System;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models;

public sealed class ProductMappingLevelSources : IModel
{
    [Key]
    public long ProductMappingLevelSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int? SiteSystemId { get; set; }
    public string ProductType { get; set; }
    public string ProductLevel { get; set; }
}
