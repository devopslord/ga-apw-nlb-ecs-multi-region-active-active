﻿using Svc.Extensions.Core.Filter;
using Svc.Extensions.Core.Value;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Domain.Filters;
public class MappingSystemFilter : DefaultFilter, IFilter<MappingSystem>
{
    public PropertyValue<List<Guid>>? MappingSystemUidCollection { get; set; }
    public PropertyValue<Guid>? MappingSystemUid { get; set; }
}
