﻿using Svc.Extensions.Core.Filter;
using Svc.Extensions.Core.Value;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Domain.Filters;
public class ProductMappingFilter : DefaultFilter, IFilter<ProductMapping>
{
    public PropertyValue<List<Guid>>? ProductMappingUidCollection { get; set; }
    public PropertyValue<Guid>? ProductMappingUid { get; set; }
}
