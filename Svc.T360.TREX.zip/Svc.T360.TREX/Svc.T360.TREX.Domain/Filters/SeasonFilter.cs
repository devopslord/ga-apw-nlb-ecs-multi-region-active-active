﻿using Svc.Extensions.Core.Filter;
using Svc.Extensions.Core.Value;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Domain.Filters;
public class SeasonFilter : DefaultFilter, IFilter<Season>
{
    public PropertyValue<List<Guid>>? SeasonUidCollection { get; set; }
    public PropertyValue<Guid>? SeasonUid { get; set; }
}
