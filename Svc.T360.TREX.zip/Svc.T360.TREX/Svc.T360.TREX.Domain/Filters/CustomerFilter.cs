﻿using Svc.Extensions.Core.Filter;
using Svc.Extensions.Core.Value;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Domain.Filters;
public class CustomerFilter : DefaultFilter, IFilter<Customer>
{
    public PropertyValue<List<Guid>>? CustomerUidCollection { get; set; }
    public PropertyValue<Guid>? CustomerUid { get; set; }
}
