﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models;

[Table("product_mapping_product_sources")]
internal class ProductMappingProductSourcesDbModel : IDbModel
{
    [Key]
    public long ProductMappingProductSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int? HomeSiteId { get; set; }
    public string Product { get; set; }
}
