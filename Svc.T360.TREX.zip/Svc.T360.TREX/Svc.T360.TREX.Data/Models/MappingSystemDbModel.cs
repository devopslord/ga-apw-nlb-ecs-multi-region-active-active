﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models;

[Table("mapping_systems")]
internal class MappingSystemDbModel : IDbModel
{
    [Key]
    public int MappingSystemId { get; set; }
    [GuidKey]
    public Guid MappingSystemUid { get; set; }
    [StringKey]
    public string? MappingSystemCode { get; set; }
    public string? MappingSystemName { get; set; }
}