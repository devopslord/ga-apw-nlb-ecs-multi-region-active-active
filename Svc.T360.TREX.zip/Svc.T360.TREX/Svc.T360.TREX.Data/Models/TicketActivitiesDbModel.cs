﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models
{
    [Table("tickets")]
    internal class TicketActivitiesDbModel : IDbModel
    {
        [Key]
        public long TicketActivityId { get; set; }                
        public int TicketId { get; set; }
        public DateTime? ActivityDate { get; set; }
        public DateTime? ActivityTime { get; set; }
        public int ProductMappingId { get; set; }
        public int SharedSiteId { get; set; }
        public string? RedemptionProduct { get; set; }      
    }
}
