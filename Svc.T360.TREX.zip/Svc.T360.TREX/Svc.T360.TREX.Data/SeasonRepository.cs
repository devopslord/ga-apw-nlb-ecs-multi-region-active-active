﻿using Microsoft.Extensions.Logging;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.T360.TREX.Data.Abstractions;
using Svc.T360.TREX.Data.Models;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Data;

internal class SeasonRepository(IDbRepositoryAdapter<Season> repositoryAdapter, ILogger<SeasonRepository> logger)
    : DbRepository<Season, SeasonDbModel>(repositoryAdapter), ISeasonRepository
{
    public override Task<int> DeleteAsync(Season item)
    {
        // Example

        logger.LogDebug("Deleting season {Id}", item.SeasonId);

        return base.DeleteAsync(item);
    }
}
