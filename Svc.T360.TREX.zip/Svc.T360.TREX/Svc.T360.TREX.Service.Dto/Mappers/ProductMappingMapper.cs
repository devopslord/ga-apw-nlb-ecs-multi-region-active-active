﻿using Riok.Mapperly.Abstractions;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.Mappers;

[Mapper]
public partial class ProductMappingMapper : IMapper<ProductMapping, ProductMappingDto>
{
    public static partial ProductMappingDto ToDto(ProductMapping source);
    public static partial ProductMapping ToModel(ProductMappingDto source);
}
