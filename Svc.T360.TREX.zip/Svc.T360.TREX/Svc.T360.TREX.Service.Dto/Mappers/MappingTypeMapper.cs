﻿using Riok.Mapperly.Abstractions;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.Mappers;

[Mapper]
public partial class MappingTypeMapper : IMapper<MappingType, MappingTypeDto>
{
    public static partial MappingTypeDto ToDto(MappingType source);
    public static partial MappingType ToModel(MappingTypeDto source);
}
