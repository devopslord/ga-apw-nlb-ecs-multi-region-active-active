﻿using Riok.Mapperly.Abstractions;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.Mappers;

[Mapper]
public partial class SeasonMapper : IMapper<Season, SeasonDto>
{
    public static partial SeasonDto ToDto(Season source);
    public static partial Season ToModel(SeasonDto source);
}
