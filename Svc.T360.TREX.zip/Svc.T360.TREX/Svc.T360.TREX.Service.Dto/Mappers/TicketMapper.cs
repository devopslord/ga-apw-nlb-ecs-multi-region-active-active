﻿using Riok.Mapperly.Abstractions;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.Mappers;

[Mapper]
public partial class TicketMapper : IMapper<Ticket, TicketDto>
{
    public static partial TicketDto ToDto(Ticket source);
    public static partial Ticket ToModel(TicketDto source);
}
