﻿using Riok.Mapperly.Abstractions;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.Mappers;

[Mapper]
public partial class TicketHeaderMapper : IMapper<TicketHeader, TicketHeaderDto>
{
    public static partial TicketHeaderDto ToDto(TicketHeader source);
    public static partial TicketHeader ToModel(TicketHeaderDto source);
}
