﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models;
public class ProductMappingAttributeSourcesDto : IDtoModel<ProductMappingAttributeSources>
{
    public long ProductMappingAttributeSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int? SiteSystemId { get; set; }
    public string ProductAttribute { get; set; }
}
