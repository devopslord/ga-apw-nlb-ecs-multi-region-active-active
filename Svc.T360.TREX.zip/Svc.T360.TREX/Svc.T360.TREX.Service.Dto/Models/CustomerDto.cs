﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models
{
    public class CustomerDto : IDtoModel<Customer>
    {
        public long CustomerId { get; set; }
        public Guid CustomerUid { get; set; }
        public DateTime CreateDateTime { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public string? UpdatedBy { get; set; }
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }
        public string? PictureFile { get; set; }
        public string? Phone1 { get; set; }
        public string? Phone1Extension { get; set; }
        public string? Phone2 { get; set; }
        public string? Phone2Extension { get; set; }
        public string? Fax { get; set; }
        public string? FaxExtension { get; set; }
        public string? Email { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? Country { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Zip { get; set; }
        #region Property Setter Properties
        [OdmRequiredProperty(nameof(CustomerCode))]
        [OdmRequiredProperty(nameof(CustomerName))]
        public string? Description { get; set; }
        #endregion
    }
}
