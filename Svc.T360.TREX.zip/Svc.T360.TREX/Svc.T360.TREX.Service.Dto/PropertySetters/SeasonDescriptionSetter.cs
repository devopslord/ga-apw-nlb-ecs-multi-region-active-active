﻿using Svc.Extensions.Odm.Abstractions;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.PropertySetters;
internal class SeasonDescriptionSetter : IPropertySetter<SeasonDto>
{
    public string PropertyName => nameof(SeasonDto.Description);

    public async Task Set(SeasonDto obj, ObjectDefinition? def)
    {
        obj.Description = await Task.FromResult($"[{obj.SeasonCode}] {obj.SeasonName}");
    }

    public async Task Set(List<SeasonDto> collection, ObjectDefinition? def)
    {
        foreach (var obj in collection)
        {
            obj.Description = await Task.FromResult($"[{obj.SeasonCode}] {obj.SeasonName}");
        }
    }
}
