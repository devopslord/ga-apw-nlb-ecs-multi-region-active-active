﻿using Svc.Extensions.Odm.Abstractions;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.PropertySetters;
internal class MappingSystemDescriptionSetter : IPropertySetter<MappingSystemDto>
{
    public string PropertyName => nameof(MappingSystemDto.Description);

    public async Task Set(MappingSystemDto obj, ObjectDefinition? def)
    {
        obj.Description = await Task.FromResult($"[{obj.MappingSystemCode}] {obj.MappingSystemName}");
    }

    public async Task Set(List<MappingSystemDto> collection, ObjectDefinition? def)
    {
        foreach (var obj in collection)
        {
            obj.Description = await Task.FromResult($"[{obj.MappingSystemCode}] {obj.MappingSystemName}");
        }
    }
}
