﻿using Microsoft.Extensions.DependencyInjection;
using Svc.T360.TREX.Data.External.SF.SFTS.Abstractions;

namespace Svc.T360.TREX.Data.External.SF.SFTS.DependencyInjection;
public static class ServiceCollectionExtensions
{
    public static void AddExternalSFTSDependencies(this IServiceCollection services)
    {
        // client
        services.AddHttpClient<SFTSClient>();

        // repo
        services.AddScoped<ISFTSRepository, SFTSRepository>();
    }
}
