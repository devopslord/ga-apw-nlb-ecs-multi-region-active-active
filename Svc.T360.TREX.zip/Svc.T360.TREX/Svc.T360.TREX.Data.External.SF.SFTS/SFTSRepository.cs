﻿using Svc.T360.TREX.Data.External.SF.SFTS.Abstractions;

namespace Svc.T360.TREX.Data.External.SF.SFTS;
internal class SFTSRepository : ISFTSRepository
{
}
