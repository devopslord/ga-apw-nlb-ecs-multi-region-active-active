﻿using Microsoft.Extensions.Logging;
using Quest.Http;
using Quest.Http.Configurations;
using Quest.Http.Constants;
using Quest.Http.Contexts;
using Quest.Http.Extensions;
using Quest.Http.Requests;
using System.Text.Json;

namespace Svc.T360.TREX.Data.External.SF.SFTS;
internal class SFTSClient(ILogger<SFTSClient> logger, HttpClient client, IQuestContext questContext) 
    : IHttpMultiInstanceQuestClient
{
    public string Name => nameof(SFTSClient);
    public QuestMultiInstanceClientConfiguration? Configuration { get; } = questContext.TryResolveMultiServerClientConfiguration<SFTSClient>();
    public List<QuestInstanceConfiguration> Instances => Configuration?.Instances ?? [];
    public string MediaType => MediaTypeConstants.ApplicationJson;
    public bool LogRequestContent { get; } = questContext.LogRequestContent;
    public ILogger? Logger { get; } = logger;
    public Dictionary<string, string>? Headers { get; } = [];

    public async Task<T?> SendReceiveAsync<T>(string instanceKey, IHttpRequest<T> request)
        => Deserialize<T>(await client.GetResponseStringAsync(instanceKey, this, request));

    private static T? Deserialize<T>(string? content)
        => content == null ? default : JsonSerializer.Deserialize<T>(content);
}
