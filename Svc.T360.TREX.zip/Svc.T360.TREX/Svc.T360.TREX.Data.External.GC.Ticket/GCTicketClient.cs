﻿using Microsoft.Extensions.Logging;
using Quest.Http.Configurations;
using Quest.Http.Constants;
using Quest.Http.Contexts;
using Quest.Http.Extensions;
using Quest.Http.GraphQL;
using Quest.Http.GraphQL.Extensions;
using Quest.Http.GraphQL.Requests;

namespace Svc.T360.TREX.Data.External.GC.Ticket;
internal class GCTicketClient(ILogger<GCTicketClient> logger, HttpClient client, IQuestContext questContext)
    : IGraphQLMultiInstanceQuestClient
{
    public string Name => nameof(GCTicketClient);    
    public QuestMultiInstanceClientConfiguration? Configuration { get; } = questContext.TryResolveMultiServerClientConfiguration<GCTicketClient>();
    public List<QuestInstanceConfiguration> Instances => Configuration?.Instances ?? [];
    public string MediaType => MediaTypeConstants.ApplicationJson;
    public bool LogRequestContent { get; } = questContext.LogRequestContent;
    public ILogger? Logger { get; } = logger;
    public Dictionary<string, string>? Headers { get; } = [];
    public async Task<T?> SendReceiveAsync<T>(string instanceKey, IGraphQLRequest<T> request)
        => request.DeserializeGraphQLResponse(await client.GetResponseStringAsync(instanceKey, this, request));
}
