﻿using Quest.Http.GraphQL.Builder;
using Svc.Extensions.Core.Value;
using Svc.T360.TREX.Data.External.GC.Ticket.Abstractions;
using Svc.T360.TREX.Data.External.GC.Ticket.Filters;
using Svc.T360.TREX.Data.External.GC.Ticket.Models;

namespace Svc.T360.TREX.Data.External.GC.Ticket;
internal class GCTicketRepository(GCTicketClient client)
    : IGCTicketRepository
{
    // get products
    public async Task<IEnumerable<GCProductDto>?> GetAllActiveProductsAsync(string siteId)
        => await client.SendReceiveAsync(siteId,
            QuestGraphQLBuilder.QueryOperation()
                .Query<GCProductDto>("productsByFilter")
                .AddVariable("filter", "ProductFilterInput!",
                    new ProductFilter { IsActive = PropertyValue<bool>.New(true) })
                .BuildRequest<IEnumerable<GCProductDto>>());

    // get product attributes
    public async Task<IEnumerable<GCProductAttributeDto>?> GetAllProductAttributesAsync(string siteId)
        => await client.SendReceiveAsync(siteId,
            QuestGraphQLBuilder.QueryOperation()
                .Query<GCProductAttributeDto>("productAttributes")                
                .BuildRequest<IEnumerable<GCProductAttributeDto>>());


    // get season pass types
    public async Task<IEnumerable<GCSeasonPassTypeDto>?> GetAllSeasonPassTypesAsync(string siteId)
        => await client.SendReceiveAsync(siteId,
            QuestGraphQLBuilder.QueryOperation()
                .Query<GCSeasonPassTypeDto>("seasonPassTypes")
                .BuildRequest<IEnumerable<GCSeasonPassTypeDto>>());
}
