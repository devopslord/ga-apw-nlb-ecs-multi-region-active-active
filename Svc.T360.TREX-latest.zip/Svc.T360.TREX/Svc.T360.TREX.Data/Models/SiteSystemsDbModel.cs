﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models;

[Table("site_systems")]
internal class SiteSystemDbModel : IDbModel
{
    [Key]
    public int SiteSystemId { get; set; }
    [GuidKey]
    public Guid SiteSystemUid { get; set; }    
    [StringKey]
    public string? SiteSystemCode { get; set; }
    public string? SiteSystemName { get; set; }
}