﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models;

[Table("ticket_headers")]
internal class TicketHeaderDbModel : IDbModel
{
    [Key]
    public long TicketHeaderId { get; set; }
    [GuidKey]
    public Guid TicketHeaderUid { get; set; }
    [CreatedDateTimeProperty]
    public DateTime CreateDateTime { get; set; }
    public string CreatedBy { get; set; }
    [UpdatedDateTimeProperty]
    public DateTime? Updated_DateTime { get; set; }        
    public string? UpdatedBy { get; set; }
    public string Barcode { get; set; }
    public long CustomerId { get; set; }       
}