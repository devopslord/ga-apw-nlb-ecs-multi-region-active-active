﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models;

[Table("product_mapping_level_sources")]
internal class ProductMappingLevelSourcesDbModel : IDbModel
{
    [Key]
    public long ProductMappingLevelSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int ProductTypeId { get; set; }
    public string ProductTypeName { get; set; }
    public int ProductLevelId { get; set; }
    public string ProductLevelName { get; set; }
}
