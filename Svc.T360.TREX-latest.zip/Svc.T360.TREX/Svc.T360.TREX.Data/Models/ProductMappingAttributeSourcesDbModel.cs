﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models;

[Table("product_mapping_attribute_sources")]
internal class ProductMappingAttributeSourcesDbModel : IDbModel
{
    [Key]
    public long ProductMappingAttributeSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int? ProductAttributeId { get; set; }
    public string ProductAttributeName { get; set; }
}
