﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models;

[Table("sites")]
internal class SiteDbModel : IDbModel
{
    [Key]
    public int SiteId { get; set; }
    [GuidKey]
    public Guid SiteUid { get; set; }    
    [StringKey]
    public string? SiteCode { get; set; }
    public string? SiteName { get; set; }
    public int InternalSystemSiteId { get; set; }
    public string? InternalSystemSiteCode { get; set; }
    public int SiteSystemId { get; set; }
}