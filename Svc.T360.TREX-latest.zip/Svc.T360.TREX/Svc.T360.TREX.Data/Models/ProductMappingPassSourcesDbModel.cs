﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;

namespace Svc.T360.TREX.Data.Models;

[Table("product_mapping_pass_sources")]
internal class ProductMappingPassSourcesDbModel : IDbModel
{
    [Key]
    public long ProductMappingPassSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int? SeasonPassTypeId { get; set; }
    public string SeasonPassTypeName { get; set; }
}
