﻿using Microsoft.Extensions.DependencyInjection;
using Svc.T360.TREX.Data.External.GC.Ticket.Abstractions;

namespace Svc.T360.TREX.Data.External.GC.Ticket.DependencyInjection;
public static class ServiceCollectionExtensions
{
    public static void AddExternalGCTicketDependencies(this IServiceCollection services)
    {
        // client
        services.AddHttpClient<GCTicketClient>();

        // repo
        services.AddScoped<IGCTicketRepository, GCTicketRepository>();
    }
}
