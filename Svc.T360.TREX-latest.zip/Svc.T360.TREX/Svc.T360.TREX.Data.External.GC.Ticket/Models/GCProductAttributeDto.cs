﻿namespace Svc.T360.TREX.Data.External.GC.Ticket.Models;
public class GCProductAttributeDto
{
    public string ExternalID { get; set; } = "";
    public string ExtProductAttributeID { get; set; } = "";
    public bool ForceRenewal { get; set; }
    public bool ForceUpgrade { get; set; }
    public bool IsDeleted { get; set; }
    public bool IsSharedTicketProgram { get; set; }
    public string ProductAttributeName { get; set; } = "";
    public int ProductAttributeNo { get; set; }
    public int ProductAttributeTypeNo { get; set; }
    public int? SeasonPassTypeNo { get; set; }
    public bool UpgradeIncludeValue { get; set; }
    public int? VenueNo { get; set; }
}
