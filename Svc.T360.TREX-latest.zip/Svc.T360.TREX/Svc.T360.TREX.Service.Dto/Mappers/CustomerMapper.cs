﻿using Riok.Mapperly.Abstractions;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.Mappers;

[Mapper]
public partial class CustomerMapper : IMapper<Customer, CustomerDto>
{
    public static partial CustomerDto ToDto(Customer source);

    public static partial Customer ToModel(CustomerDto source);
}
