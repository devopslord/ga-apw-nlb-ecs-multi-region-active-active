﻿using Riok.Mapperly.Abstractions;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.Service.Dto.Mappers;

[Mapper]
public partial class SiteMapper : IMapper<Site, SiteDto>
{
    public static partial SiteDto ToDto(Site source);
    public static partial Site ToModel(SiteDto source);
}
