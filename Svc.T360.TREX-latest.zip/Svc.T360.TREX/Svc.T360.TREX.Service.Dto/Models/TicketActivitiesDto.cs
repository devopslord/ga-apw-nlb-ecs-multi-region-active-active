﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models
{
    public class TicketActivitiesDto : IDtoModel<TicketActivities>
    {
        public long TicketActivityId { get; set; }
        public int TicketId { get; set; }
        public DateTime? ActivityDate { get; set; }
        public DateTime? ActivityTime { get; set; }
        public int ProductMappingId { get; set; }
        public int SharedSiteId { get; set; }
        public int RedemptionProductId { get; set; }
        public string? RedemptionProductName { get; set; }
    }
}
