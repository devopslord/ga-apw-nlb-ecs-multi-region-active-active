﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models;
public class SiteDto : IDtoModel<Site>
{
    public int SiteId { get; set; }
    public Guid SiteUid { get; set; }
    public string? SiteCode { get; set; }
    public string? SiteName { get; set; }
    public int InternalSystemSiteId { get; set; }
    public string? InternalSystemSiteCode { get; set; }
    public int SiteSystemId { get; set; }

    #region Property Setter Properties
    [OdmRequiredProperty(nameof(SiteCode))]
    [OdmRequiredProperty(nameof(SiteName))]
    public string? Description { get; set; }
    #endregion
}
