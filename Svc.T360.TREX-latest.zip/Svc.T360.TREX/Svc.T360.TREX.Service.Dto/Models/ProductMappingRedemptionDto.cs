﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models;
public class ProductMappingRedemptionDto : IDtoModel<ProductMappingRedemption>
{
    public long ProductMappingRedemptionId { get; set; }
    public long ProductMappingId { get; set; }
    public int? SharedSiteId { get; set; }
    public int? HomeSiteId { get; set; }
    public string ProductName { get; set; }
    public int ProductId { get; set; }
}
