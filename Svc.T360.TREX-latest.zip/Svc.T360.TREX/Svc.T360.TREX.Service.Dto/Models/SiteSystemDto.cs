﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models;
public class SiteSystemDto : IDtoModel<SiteSystem>
{
    public int SiteSystemId { get; set; }
    public Guid SiteSystemUid { get; set; }
    public string? SiteSystemCode { get; set; }
    public string? SiteSystemName { get; set; }
}
