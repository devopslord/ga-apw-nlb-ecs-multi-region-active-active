﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models;
public class ProductMappingLevelSourcesDto : IDtoModel<ProductMappingLevelSources>
{
    public long ProductMappingLevelSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int ProductTypeId { get; set; }
    public string ProductTypeName { get; set; }
    public string ProductLevelName { get; set; }
}
