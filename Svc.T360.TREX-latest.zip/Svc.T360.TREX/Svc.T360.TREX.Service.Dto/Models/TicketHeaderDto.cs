﻿using Svc.Extensions.Odm.Attributes;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.Service.Dto.Models;
public class TicketHeaderDto : IDtoModel<TicketHeader>
{
    public long TicketHeaderId { get; set; }
    public Guid TicketHeaderUid { get; set; }
    public DateTime CreateDateTime { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedDateTime { get; set; }
    public string? UpdatedBy { get; set; }
    public string? Barcode { get; set; }
    public long CustomerId { get; set; }
}
