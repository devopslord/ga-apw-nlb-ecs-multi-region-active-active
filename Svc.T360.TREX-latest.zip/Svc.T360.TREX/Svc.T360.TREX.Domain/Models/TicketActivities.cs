﻿using Svc.Extensions.Core.Model;
using System;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models
{
    public sealed class TicketActivities : IModel
    {
        [Key]
        public long TicketActivityId { get; set; }
        public int TicketId { get; set; }
        public DateTime? ActivityDate { get; set; }
        public DateTime? ActivityTime { get; set; }
        public int ProductMappingId { get; set; }
        public int SharedSiteId { get; set; }
        public int RedemptionProductId { get; set; }
        public string? RedemptionProductName { get; set; }
    }
}
