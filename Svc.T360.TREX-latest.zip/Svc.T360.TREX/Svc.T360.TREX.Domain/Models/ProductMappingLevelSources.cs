﻿using Svc.Extensions.Core.Model;
using System;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models;

public sealed class ProductMappingLevelSources : IModel
{
    [Key]
    public long ProductMappingLevelSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int ProductTypeId { get; set; }
    public string ProductTypeName { get; set; }
    public string ProductLevelName { get; set; }
}
