﻿using Svc.Extensions.Core.Model;
using System;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models;

public sealed class Site : IModel
{
    [Key]
    public int SiteId { get; set; }
    public Guid SiteUid { get; set; }
    public string? SiteCode { get; set; }
    public string? SiteName { get; set; }
    public int InternalSystemSiteId { get; set; }
    public string? InternalSystemSiteCode { get; set; }
    public int SiteSystemId { get; set; }
}
