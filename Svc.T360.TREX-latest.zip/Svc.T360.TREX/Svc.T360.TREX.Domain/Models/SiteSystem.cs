﻿using Svc.Extensions.Core.Model;
using System;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models;

public sealed class SiteSystem : IModel
{
    [Key]
    public int SiteSystemId { get; set; }  
    public Guid SiteSystemUid { get; set; }  
    public string? SiteSystemCode { get; set; }
    public string? SiteSystemName { get; set; }
}
