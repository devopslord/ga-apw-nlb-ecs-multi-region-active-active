﻿using Svc.Extensions.Core.Model;
using System;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models;

public sealed class ProductMappingProductSources : IModel
{
    [Key]
    public long ProductMappingProductSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int? HomeSiteId { get; set; }
    public string ProductName { get; set; }
    public int ProductId { get; set; }
}
