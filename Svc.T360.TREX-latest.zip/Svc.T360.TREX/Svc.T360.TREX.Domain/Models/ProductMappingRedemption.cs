﻿using Svc.Extensions.Core.Model;
using System;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models;

public sealed class ProductMappingRedemption : IModel
{
    [Key]
    public long ProductMappingRedemptionId { get; set; }
    public long ProductMappingId { get; set; }
    public int? SharedSiteId { get; set; }
    public int? HomeSiteId { get; set; }
    public string ProductName { get; set; }
    public int ProductId { get; set; }
}
