﻿using Svc.Extensions.Core.Model;
using System;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models;

public sealed class TicketHeaderAlternativeBarcode : IModel
{
    [Key]
    public int TicketHeaderAlternativeBarcodeId { get; set; }
    public Guid TicketHeaderAlternativeBarcodeUid { get; set; }
    public long TicketHeaderId { get; set; }
    public string? Barcode { get; set; }
    public TicketHeader? TicketHeader { get; set; }
}
