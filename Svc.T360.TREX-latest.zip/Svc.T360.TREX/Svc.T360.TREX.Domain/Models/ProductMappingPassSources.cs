﻿using Svc.Extensions.Core.Model;
using System;
using System.ComponentModel.DataAnnotations;

namespace Svc.T360.TREX.Domain.Models;

public sealed class ProductMappingPassSources : IModel
{
    [Key]
    public long ProductMappingPassSourceId { get; set; }
    public long ProductMappingId { get; set; }
    public int? SeasonPassTypeId { get; set; }
    public string SeasonPassTypeName { get; set; }
}
