﻿using Svc.Extensions.Core.Model;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.GraphQL.InputTypes;

public class ProductMappingRedemptionSaveInput : IInputModel<ProductMappingRedemption>
{
    public long ProductMappingRedemptionId { get; set; }
    public long ProductMappingId { get; set; }
    public int? SharedSiteId { get; set; }
    public int? HomeSiteId { get; set; }
    public string Product { get; set; } = "";
}
