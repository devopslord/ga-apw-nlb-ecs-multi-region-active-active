﻿using Svc.Extensions.Core.Model;
using Svc.T360.TREX.Domain.Models;

namespace Svc.T360.TREX.GraphQL.InputTypes;

public class TicketHeaderSaveInput : IInputModel<TicketHeader>
{
    public long TicketHeaderId { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public int SiteId { get; set; }
    public string? Barcode { get; set; }
    public long CustomerId { get; set; }
}
