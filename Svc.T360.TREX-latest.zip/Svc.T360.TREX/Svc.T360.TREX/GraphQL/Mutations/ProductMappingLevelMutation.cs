﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class ProductMappingLevelSourcesMutation
{
    public async Task<GraphQLResponse<ProductMappingLevelSources?>> ProductMappingLevelSourcesSaveAsync(ProductMappingLevelSourcesSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<ProductMappingLevelSources> svc)
        => await operation.ExecuteAsync(nameof(ProductMappingLevelSourcesSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<ProductMappingLevelSourcesSaveInput, ProductMappingLevelSources>()));

    public async Task<GraphQLResponse<IEnumerable<ProductMappingLevelSources>>> ProductMappingLevelSourcessSaveAsync(IEnumerable<ProductMappingLevelSourcesSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<ProductMappingLevelSources> svc)
        => await operation.ExecuteAsync(nameof(ProductMappingLevelSourcessSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<ProductMappingLevelSourcesSaveInput, ProductMappingLevelSources>()).ToList()));
}
