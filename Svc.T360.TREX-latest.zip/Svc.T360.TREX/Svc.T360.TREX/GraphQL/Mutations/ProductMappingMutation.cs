﻿using HotChocolate;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Core.Model;
using Svc.Extensions.Service;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.GraphQL.InputTypes;

namespace Svc.T360.TREX.GraphQL.Mutations;

[ExtendObjectType(nameof(Mutation))]
public class ProductMappingMutation
{
    public async Task<GraphQLResponse<ProductMapping?>> ProductMappingSaveAsync(ProductMappingSaveInput input,
        [Service] IMutationOperation operation, [Service] IBaseService<ProductMapping> svc)
        => await operation.ExecuteAsync(nameof(ProductMappingSaveAsync),
            async () => await svc.SaveAsync(input.ConvertToModel<ProductMappingSaveInput, ProductMapping>()));

    public async Task<GraphQLResponse<IEnumerable<ProductMapping>>> ProductMappingsSaveAsync(IEnumerable<ProductMappingSaveInput> input,
        [Service] IMutationOperation operation, [Service] IBaseService<ProductMapping> svc)
        => await operation.ExecuteAsync(nameof(ProductMappingsSaveAsync),
            async () => await svc.SaveAsync(input.Select(x => x.ConvertToModel<ProductMappingSaveInput, ProductMapping>()).ToList()));
}
