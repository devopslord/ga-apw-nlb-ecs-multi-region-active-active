﻿using HotChocolate;
using HotChocolate.Resolvers;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Odm.HotChocolate;
using Svc.Extensions.Service.Dto;
using Svc.T360.TREX.Domain.Filters;
using Svc.T360.TREX.Domain.Models;
using Svc.T360.TREX.Service.Dto.Models;

namespace Svc.T360.TREX.GraphQL.Queries;

[ExtendObjectType(nameof(Query))]
public class ProductMappingProductSourcesQuery
{
    public async Task<GraphQLResponse<IEnumerable<ProductMappingProductSourcesDto>>> GetProductMappingProductSourcessAsync(IResolverContext context,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<ProductMappingProductSources, ProductMappingProductSourcesDto> svc)
        => await operation.ExecuteAsync(nameof(GetProductMappingProductSourcessAsync),
            async () => await svc.GetAllAsync(context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)) ??
                        Enumerable.Empty<ProductMappingProductSourcesDto>());

    public async Task<GraphQLResponse<ProductMappingProductSourcesDto?>> GetProductMappingProductSourcesAsync(IResolverContext context, long id,
    [Service] IQueryOperation operation, [Service] IBaseDtoService<ProductMappingProductSources, ProductMappingProductSourcesDto> svc)
    => await operation.ExecuteAsync(nameof(GetProductMappingProductSourcesAsync),
        async () => await svc.GetAsync(id, context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)));
}
